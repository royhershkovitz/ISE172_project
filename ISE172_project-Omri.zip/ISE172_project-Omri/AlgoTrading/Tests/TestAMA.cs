﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
namespace AlgoTrading.Tests
{
    [TestFixture]
    class TestAMA
    {
    }
}
