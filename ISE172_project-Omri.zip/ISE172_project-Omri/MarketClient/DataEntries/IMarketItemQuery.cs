﻿namespace MarketClient.DataEntries
{
    public interface IMarketItemQuery
    {
    }
}