﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;

namespace SandBox2
{
    class Gg
    {
        static void Main(string[] args)
        {
            Gg AI = new Gg();
            for (int index = 0; index < commudities.Length; index++)
                Console.WriteLine(commudities[index]);
            AI.getCurrAVG();
            for (int index = 0; index < commudities.Length; index++)
                Console.WriteLine(commuditiesAVGvalues[index]);
            Console.Read();
        }

        //We will use it to Abort the while loop, and to know if we finish the loop
        private bool running = true;
        //private MarketClientOptions UserOptions = new MarketClientOptions(true);
        private static readonly int topActions = 18;
        private static int actions;
        private static readonly int[] commudities = new int[] { 0, 1, 2 };
        public static double[] commuditiesAVGvalues = new double[commudities.Length];

        //This function is for the use of other classes to stop the algorithm
        public void StopAlgorithemAI()
        {
            running = false;
        }


        public void RunAlgorithemAI2()
        {
            while (running)
            {
                Trace.WriteLine("\n\nbuy");
                //Buying all possible commodities for a cheap price
                for (int i = 0; i < 9; i++)//missing commodity 9
                {
                    int price = 1;
                    int commodity = i;
                    int amount = 1;
                  //  UserOptions.SendBuyRequest(price, commodity, amount);
                    Thread.Sleep(TimeSpan.FromSeconds(0.1));
                }

                Trace.WriteLine("sell");
                //Selling them for more.
                for (int i = 0; i < 9; i++)
                {
                    int price = 15;
                    int commodity = i;
                    int amount = 1;
                  //  UserOptions.SendSellRequest(price, commodity, amount);
                    Thread.Sleep(TimeSpan.FromSeconds(0.1));
                    Trace.WriteLine(i);
                }
                pauseAlgorithem();
            }
            running = true;
        }

        private void pauseAlgorithem()
        {
            if (running)
            {
                Trace.WriteLine("sleep");
                Thread.Sleep(TimeSpan.FromSeconds(8.2));//10-0.1*18 = 8.2
            }

            Trace.WriteLine("keep Running: " + running);
        }

        //pause the program for 8.2 seconds
        private void pause()
        {
            if (running)
            {
                Trace.WriteLine("sleep");
                Thread.Sleep(TimeSpan.FromSeconds(8.2));//10-0.1*18 = 8.2
            }

            Trace.WriteLine("keep Running: " + running);
        }

        public void getCurrAVG()
        {
            String connectionString = @"Data Source=ise172.ise.bgu.ac.il;Initial Catalog=history;User ID=labuser;Password=wonsawheightfly";
            SqlConnection myConnection = new SqlConnection(connectionString);
            try
            {
               
                for (int index = 0; index < commudities.Length; index++)
                {
                    myConnection.Open();
                    String sql = @"SELECT Avg(price) FROM dbo.items where commodity=" + commudities[index];
                    SqlCommand myCommand = new SqlCommand(sql, myConnection);
                    SqlDataReader reader = myCommand.ExecuteReader();
                    while (reader.Read())
                    {
                        
                        commuditiesAVGvalues[index] = Double.Parse(reader[0].ToString());
                    }
                    Thread.Sleep(TimeSpan.FromSeconds(0.1));
                    myConnection.Close();
                }

                
            }
             catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            Console.WriteLine("close connection");
                 for (int index = 0; index < 3; index++)//missing commodity 9
                {
                   
                         double avg=commuditiesAVGvalues[index];
                         UserOptions.SendBuyRequest(avg-2, index, 10);
                         UserOptions.SendSellRequest(avg+2, index, 10);
                    Thread.Sleep(TimeSpan.FromSeconds(0.1));
                         
                
                 }
           
        }  
    }
}
