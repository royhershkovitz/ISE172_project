﻿using System;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Threading;
using AlgoTrading;

namespace SandBox2
{
    //This class can run on thread multiple times
    public class myAIAlgorithem
    {

        //We will use it to Abort the while loop, and to know if we finish the loop
        private bool running = true;
        private MarketClientOptions UserOptions = new MarketClientOptions(true);
        private int topActions = 18;
        private int actions;
        private static readonly int[] commudities = new int[]{0,1,2};
        public static int[] commuditiesAVGvalues = new int[commudities.Length];

        //This function is for the use of other classes to stop the algorithm
        public void StopAlgorithemAI()
        {
            running = false;
        }

        public void RunAlgorithemAI()
        {
            actions = topActions;
            while (running)
            {
                Trace.WriteLine("\n\nbuy");
                //Buying all possible commodities for a cheap price
                for (int i = 0; i < 9; i++)//missing commodity 9
                {
                    int price = 1;
                    int commodity = i;
                    int amount = 1;
                    UserOptions.SendBuyRequest(price, commodity, amount);
                    Thread.Sleep(TimeSpan.FromSeconds(0.1));
                }

                Trace.WriteLine("sell");
                //Selling them for more.
                for (int i = 0; i < 9; i++)
                {
                    int price = 15;
                    int commodity = i;
                    int amount = 1;
                    UserOptions.SendSellRequest(price, commodity, amount);
                    Thread.Sleep(TimeSpan.FromSeconds(0.1));
                    Trace.WriteLine(i);
                }
                if (running)
                {
                    Trace.WriteLine("sleep");
                    Thread.Sleep(TimeSpan.FromSeconds(8.2));//10-0.1*18 = 8.2
                }
                Trace.WriteLine("keep Running: " + running);               
            }
            running = true;
        }    

         public void RunAlgorithemAI2()
        {
            while (running)
            {
                Trace.WriteLine("\n\nbuy");
                //Buying all possible commodities for a cheap price
                for (int i = 0; i < 9; i++)//missing commodity 9
                {
                    int price = 1;
                    int commodity = i;
                    int amount = 1;
                    UserOptions.SendBuyRequest(price, commodity, amount);
                    Thread.Sleep(TimeSpan.FromSeconds(0.1));
                }

                Trace.WriteLine("sell");
                //Selling them for more.
                for (int i = 0; i < 9; i++)
                {
                    int price = 15;
                    int commodity = i;
                    int amount = 1;
                    UserOptions.SendSellRequest(price, commodity, amount);
                    Thread.Sleep(TimeSpan.FromSeconds(0.1));
                    Trace.WriteLine(i);
                }
                pauseAlgorithem();           
            }
            running = true;
        }

         private void pauseAlgorithem()
         {
             if (running)
             {
                 Trace.WriteLine("sleep");
                 Thread.Sleep(TimeSpan.FromSeconds(8.2));//10-0.1*18 = 8.2
             }

             Trace.WriteLine("keep Running: " + running);
         }

        //pause the program for 8.2 seconds
         private void pause(){
            if (running)
                {
                    Trace.WriteLine("sleep");
                    Thread.Sleep(TimeSpan.FromSeconds(8.2));//10-0.1*18 = 8.2
                }

            Trace.WriteLine("keep Running: " + running);    
        }

         public void getCurrAVG()
         {
            String connectionString = @"Data Source=ise172.ise.bgu.ac.il;Initial Catalog=history;User ID=labuser;Password=wonsawheightfly";
            SqlConnection myConnection = new SqlConnection(connectionString);            
        
            try
            {
              myConnection.Open();
              for(int index = 0;  index < commudities.Length; index++)
              {
                  String sql = @"SELECT AVG(price) FROM dbo.items where commudity=" + commudities[index];
                  SqlCommand myCommand = new SqlCommand(sql, myConnection);
                  SqlDataReader reader = myCommand.ExecuteReader();
                  commuditiesAVGvalues[index] = int.Parse(reader[0].ToString());
                  Thread.Sleep(TimeSpan.FromSeconds(0.1));
              }
              myConnection.Close();
            }
            catch (Exception e)
            {
              Console.WriteLine(e.ToString());
            }
            Console.WriteLine("close connection");
        }         
    }
}
