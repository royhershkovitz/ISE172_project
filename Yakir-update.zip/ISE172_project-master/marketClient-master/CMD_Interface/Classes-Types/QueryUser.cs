﻿using System;

namespace AlgoTrading
{
    class QueryUser
    {
        public String type = "queryUser";        
    }
}
