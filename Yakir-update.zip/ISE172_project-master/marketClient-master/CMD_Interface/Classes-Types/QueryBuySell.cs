﻿using System;

namespace AlgoTrading
{
    class QueryBuySell
    {
        public String type = "queryBuySell";
        int id;       

        public QueryBuySell(int id)
        {
            this.id = id;
        }
    }
}
