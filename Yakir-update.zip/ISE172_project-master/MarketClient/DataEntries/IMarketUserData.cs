﻿namespace MarketClient.DataEntries
{
    public interface IMarketUserData
    {
    }
}