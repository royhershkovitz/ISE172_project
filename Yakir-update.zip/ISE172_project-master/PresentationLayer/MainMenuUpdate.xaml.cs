﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainMenuUpdate.xaml
    /// </summary>
    public partial class MainMenuUpdate : Window
    {
        public MainMenuUpdate()
        {
            InitializeComponent();
        }

        private void B_Credits_Click(object sender, RoutedEventArgs e)
        {
            Credits win = new Credits();
            win.Show();
            Window.GetWindow(this).Close();
        }

        private void B_X_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void B_Requests_Click(object sender, RoutedEventArgs e)
        {
            Requests win2 = new Requests();
            win2.Show();
            this.Close();
        }
    }
}
