﻿using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace AlgoTrading.Tests
{
    [TestFixture]
    class TestClientOptions
    {
        [SetUp]
        public void createUser()
        {
            //TO-DO definde user
        }

        [Test]
        public void sendBuyRequest()
        {
            //TO-DO some inputs and outputs
            //how to work with Nunit -> //https://piazza.com/class_profile/get_resource/iztt8b0ie121hg/j169adn32ky6n0
        }
    }
}
