ISE17 Market client repository.

This repository contains the code necessary for the students to communicate with the market emulator.
