﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AlgoTrading;
using System.Diagnostics;

namespace PresentationLayer
{
    /// <summary>
    /// Interaction logic for AI.xaml
    /// </summary>
    // for AI uses
    public class myAIAlgorithem
    {   
        private bool running = true;
        private bool midRun = false;
        private AI _myAMA;
        private MarketClientOptions UserOptions = new MarketClientOptions();
        public myAIAlgorithem(AI myAMA)
        {
            _myAMA = myAMA;
        }
        public void stopAlgorithemAI()
        {
            running = false;
        }
        public bool canAbortThread()
        {
            return midRun;
        }
        public void runAlgorithemAI()
        {
            while(running)
            {
                Trace.WriteLine("\n\nbuy");
                for (int i = 0; i < 9; i++)//missing commodity 9
                {
                    int price = 1;
                    int commodity = i;
                    int amount = 1;
                    UserOptions.SendBuyRequest(price, commodity, amount);
                    Thread.Sleep(TimeSpan.FromSeconds(0.01));
                }

                Trace.WriteLine("sell");
                for (int i = 0; i < 9; i++)
                {
                    int price = 15;
                    int commodity = i;
                    int amount = 1;
                    UserOptions.SendSellRequest(price, commodity, amount);
                    Thread.Sleep(TimeSpan.FromSeconds(0.01));
                    //Trace.WriteLine(i);
                }
                Trace.WriteLine("sleep");
                Thread.Sleep(TimeSpan.FromSeconds(10));
                Trace.WriteLine("keeprunning: " + running);
                //_myAMA.updateFunds();
                /*form.Label.Invoke((MethodInvoker)delegate {
                // Running on the UI thread
                form.Label.Text = newText;
                });*/
            }
            midRun = true;        
        }
    }

    public partial class AI : Window
    {        
        private Thread _run = null;
        private myAIAlgorithem _ama = null;
        private MarketClientOptions _UserOptions = new MarketClientOptions();
        private float startValue;
        public AI()
        {           
            InitializeComponent();
            startValue = _UserOptions.getFunds();
            myFunds.Text = startValue.ToString();
            start(null, null);
        }

        private void stop(object sender, RoutedEventArgs e)
        {
            if (_ama != null) {
                if (_run != null && _run.IsAlive)
                {
                    _ama.stopAlgorithemAI();
                    Trace.WriteLine("stop pressed");
                    while (_ama.canAbortThread())
                        Thread.Sleep(TimeSpan.FromSeconds(1));
                    //_run.Abort();
                    _run.Join();
                    Trace.WriteLine("AI aborted");
                    updateFunds();
                }
            }
        }

        public void updateFunds()
        {
            float tValue = _UserOptions.getFunds();
            float revenue = tValue-startValue;
            myFunds.Text = tValue.ToString() + ", revenue " + revenue;
        }


        private void back(object sender, RoutedEventArgs e)
        {
            stop(null, null);
            MainMenuUpdate win = new MainMenuUpdate();
            win.Show();
            this.Close();
        }

        private void start(object sender, RoutedEventArgs e)
        {
            if (_run == null || !_run.IsAlive) {
                _ama = new myAIAlgorithem(this);                
                _run = new Thread(new ThreadStart(_ama.runAlgorithemAI));
                _run.Start();
            }
        }
    }
}
