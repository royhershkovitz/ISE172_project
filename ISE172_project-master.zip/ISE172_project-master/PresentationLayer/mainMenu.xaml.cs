﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;


namespace PresentationLayer
{
    /// <summary>
    /// This page is the program main menu
    /// </summary>
    
    public partial class mainMenu : Page
    {
        public mainMenu()
        {
            InitializeComponent();
        }

        //open AMA options
        private void AI_Click(object sender, RoutedEventArgs e)
        {
            throw new NotSupportedException("ToBeImplemented");
        }

        //open credits page
        private void Credits_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new CreditsPage();
        }

        //cmd func important methods
        [DllImport("Kernel32")]
        public static extern void AllocConsole();

        [DllImport("Kernel32", SetLastError = true)]
        public static extern void FreeConsole();

        //this func can be run just once
        private void Requests_Click(object sender, RoutedEventArgs e)
        {
            Requests win = new Requests();
            win.Show();
            Window.GetWindow(this).Close();


        }

        //exit from the program
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            ((MainWindow) Window.GetWindow(this)).exitProgram();
        }

        private void Main_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {

        }
    }
}
